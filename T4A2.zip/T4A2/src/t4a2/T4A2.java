
package t4a2;
import java.util.Scanner;
public class T4A2 {

    public static void main(String[] args) {
      
        }
  public static void ejercicio1(String[] args) {
        for (int m = 1; m <= 10; m++) {
            System.out.println("Tabla de multiplicar del " + m);
            for (int n = 1; n <= 10; n++) {
                System.out.println(m  + " x " + n + " =" + m*n);
            }
            
        }
        
    }
     public static void ejercicio2(){

    Scanner leer=new Scanner (System.in);    
    System.out.println("Ingresa un numero: ");

    int b = leer.nextInt();
    
    boolean esPrimo = true;

     
    for (int n = 2; n <= b; n++) {
      esPrimo = true;
      for (int i = 2; i < n; i++) {
        if (n % i == 0) {
          esPrimo = false;
          
        }
      }

      if (esPrimo) {
        System.out.print(n + " ");
      }
    }
    System.out.println();
  }
  
     public static void ejercicio3(String[] args){
          Scanner leer = new Scanner(System.in);
         int nElementos;
      int contador_Pares = 0;
      int contador_Impares = 0;
      int b = 0;
      int valor;
      
      
      System.out.print("coloque la cantidad de elemtos que desea : ");
      nElementos = leer.nextInt();
      
      while(b < nElementos ){
          System.out.println("coloque el elementonumero" + b + " : ");
          valor = leer.nextInt();
          
          if (valor % 2 == 0){
               contador_Pares ++;
      }
          else{
              contador_Impares ++;
          }
          b ++;
 }
     System.out.println(" ");
      System.out.println("La cantidad de elementos pares son " + contador_Pares);
      System.out.println("La cantidad de elementos impares son " + contador_Impares);
            
    }
    public static void ejercicio4(String[] args) {
		Scanner leer=new Scanner(System.in);
		   System.out.println("Ingresa una palabra para invertir: ");
		String palabra=leer.next();
		String invertida = "";

		for (int inicio = palabra.length() - 1; inicio >= 0; inicio--) {

			invertida += palabra.charAt(inicio);
		}
		System.out.println("Cadena original: " + palabra);
		System.out.println("Cadena invertida: " + invertida);

	}

}
